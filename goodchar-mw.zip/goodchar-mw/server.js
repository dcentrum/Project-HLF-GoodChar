// BASE SETUP
// =============================================================================

// call the packages we need
var express    = require('express');
var bodyParser = require('body-parser');
var app        = express();
var morgan     = require('morgan');
 
app.use(morgan('dev')); // log requests to the console

// configure body parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port     = process.env.PORT || 8080; // set our port

// DATABASE SETUP
var mongoose   = require('mongoose');
mongoose.connect('mongodb://localhost:27017/goodchar', { useMongoClient: true}); // connect to our database



// Handle the connection event
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

db.once('open', function() {
  console.log("DB connection alive");
});

//  models lives here
var Causes     = require('./app/models/causes');
var Donations  = require('./app/models/donations');
var Donee      = require('./app/models/donee');
var Donor      = require('./app/models/donor');
var Ngo        = require('./app/models/ngo');
var Projects     = require('./app/models/projects');
var Transactions = require('./app/models/transactions');
var Volunteer    = require('./app/models/volunteer');
 
 
// ROUTES FOR OUR API
// =============================================================================

// create our router
var router = express.Router();

// middleware to use for all requests
router.use(function(req, res, next) {
	// do logging
	console.log('Something is happening.');
	next();
});

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function(req, res) {
	res.json({ message: 'hooray! welcome to our goodchar api!' });	
});

// ----------------------------------------------------
router.route('/causes')

	// create a cause (accessed at POST http://localhost:8080/causes)
	.post(function(req, res) {
		
		var causes = new Causes();		// create a new instance of the Causes model
		causes.cause_id = req.body.cause_id;  
		causes.cause_name = req.body.cause_name;
		causes.cause_type = req.body.cause_type;
		causes.comments = req.body.comments;
		

		causes.save(function(err,causes) {
			if (err)
				res.send(err);

		res.json({ message: 'cause created!' });
		});

		
	})

	// get all the causes (accessed at GET http://localhost:8080/api/causes)
	.get(function(req, res) {
		Causes.find(function(err, causes) {
			if (err)
				res.send(err);

			res.json(causes);
		});
	})

		// update the cause with this id
	.put(function(req, res) {
		var causes = {};		// create a new instance of the Causes model
		//var id = new mongoose.Types.ObjectId();
		//causes._id=id;
		causes.cause_id = req.body.cause_id;  
		causes.cause_name = req.body.cause_name;
		causes.cause_type = req.body.cause_type;
		causes.comments = req.body.comments;
		
			Causes.findOneAndUpdate({cause_id : req.body.cause_id},{$set: causes}, { multi: false, upsert: true },function(err, cause) {	
			if (err)
					res.send(err);
	
			res.json({ message: 'Cause updated!'});
		         });
	
			});

//--bala

router.route('/causes/:cause_id')

	// get the cause with that id
	.get(function(req, res) {
			Causes.find({cause_id : {$eq:req.params.cause_id}}, function(err, cause) {
			if (err)
				res.send(err);
			res.json(cause);
			});
	})
	// delete the cause with this id
	.delete(function(req, res) {
		Causes.remove({
			cause_id: req.params.cause_id
		}, function(err, cause) {
			if (err)
				res.send(err);

			res.json({ message: 'Cause '+req.params.cause_id+' Successfully deleted' });
		});
	});


//	})

//*************DONOR******************STARTS */
router.route('/donor')

	// create a donor (accessed at POST http://localhost:8080/donor)
	.post(function(req, res) {
		
		var donor = new Donor();		// create a new instance of the Causes model
		donor.donor_id = req.body.donor_id;  
		donor.donor_name = req.body.donor_name;
		donor.donor_mobile_number = req.body.donor_mobile_number;
		donor.donor_donated_items = req.body.donor_donated_items;
		
		donor.donor_donated_amount = req.body.donor_donated_amount;
		donor.donor_email_id = req.body.donor_email_id;
		donor.donor_address = req.body.donor_address;
		donor.donor_gove_id_proof = req.body.donor_gove_id_proof;
		donor.donor_biometric_details = req.body.donor_biometric_details;
		donor.donor_photo = req.body.donor_photo; 
		donor.donor_comments = req.body.donor_comments; 

		donor.save(function(err,donor) {
			if (err)
				res.send(err);

		res.json({ message: 'Donor created!' });
		});

		
	})

	// get all the donor (accessed at GET http://localhost:8080/api/donor)
	.get(function(req, res) {
		Donor.find(function(err, donor) {
			if (err)
				res.send(err);

			res.json(donor);
		});
	})

		// update the donor  with this id
	.put(function(req, res) {
		var donor = {};		// create a new instance of the Causes model
				// create a new instance of the Causes model
		donor.donor_id = req.body.donor_id;  
		donor.donor_name = req.body.donor_name;
		donor.donor_mobile_number = req.body.donor_mobile_number;
		donor.donor_donated_items = req.body.donor_donated_items;
		
		donor.donor_donated_amount = req.body.donor_donated_amount;
		donor.donor_email_id = req.body.donor_email_id;
		donor.donor_address = req.body.donor_address;
		donor.donor_gove_id_proof = req.body.donor_gove_id_proof;
		donor.donor_biometric_details = req.body.donor_biometric_details;
		donor.donor_photo = req.body.donor_photo; 
		donor.donor_comments = req.body.donor_comments; 

			Donor.findOneAndUpdate({donor_id : req.body.donor_id},{$set: donor}, { multi: false, upsert: true },function(err, donor) {	
			if (err)
					res.send(err);
			
			res.json({ message: 'Donor updated!'});
		});
	
			});

	router.route('/donor/:donor_id')

			// get the cause with that id
			.get(function(req, res) {
					Donor.find({donor_id : {$eq:req.params.donor_id}}, function(err, donor) {
					if (err)
						res.send(err);
					res.json(donor);
					});
			})
			// delete the donor with this id
			.delete(function(req, res) {
				Donor.remove({
					donor_id: req.params.donor_id
				}, function(err, donor) {
					if (err)
						res.send(err);
		
					res.json({ message: 'Donor Successfully deleted' });
				});
			});
		
		
		

//*************DONOR ******************ENDS */

//*************DONEE******************STARTS */
router.route('/donee')

	// create a donee (accessed at POST http://localhost:8080/donee)
	.post(function(req, res) {
		
		var donee = new Donee();		// create a new instance of the Causes model
		donee.donee_id = req.body.donee_id;  
		donee.donee_name = req.body.donee_name;
		donee.donee_mobile_number = req.body.donee_mobile_number;
		donee.donee_received_items = req.body.donee_received_items;
		donee.donee_received_amount = req.body.donee_received_amount;
		donee.donee_email_id = req.body.donee_email_id;
		donee.donee_address = req.body.donee_address;
		donee.donee_gove_id_proof = req.body.donee_gove_id_proof;
		donee.donee_biometric_details = req.body.donee_biometric_details;
		donee.donee_photo = req.body.donee_photo; 
		donee.donee_comments = req.body.donee_comments; 

		donee.save(function(err,donee) {
			if (err)
				res.send(err);

		res.json({ message: 'Donee created!' });
		});

		
	})

	// get all the donees (accessed at GET http://localhost:8080/api/donee)
	.get(function(req, res) {
		Donee.find(function(err, donee) {
			if (err)
				res.send(err);

			res.json(donee);
		});
	})

		// update the donee with this id
	.put(function(req, res) {
		var donee = {};		// create a new instance of the Causes model
				// create a new instance of the Causes model
				donee.donee_id = req.body.donee_id; 
				donee.donee_name = req.body.donee_name;
				donee.donee_mobile_number = req.body.donee_mobile_number;
				donee.donee_received_items = req.body.donee_received_items;
				donee.donee_received_amount = req.body.donee_received_amount;
				donee.donee_email_id = req.body.donee_email_id;
				donee.donee_address = req.body.donee_address;
				donee.donee_gove_id_proof = req.body.donee_gove_id_proof;
				donee.donee_biometric_details = req.body.donee_biometric_details;
				donee.donee_photo = req.body.donee_photo; 
				donee.donee_comments = req.body.donee_comments; 
		

				Donee.findOneAndUpdate({donee_id : req.body.donee_id},{$set: donee}, { multi: false, upsert: true },function(err, donee) {	
			if (err)
					res.send(err);
			
			res.json({ message: 'Donee updated!'+donee.donee_id});
		});
	
			});

	router.route('/donee/:donee_id')

			// get the cause with that id
			.get(function(req, res) {
					Donee.find({donee_id : {$eq:req.params.donee_id}}, function(err, donee) {
					if (err)
						res.send(err);
					res.json(donee);
					});
			})
			// delete the donee with this id
			.delete(function(req, res) {
				Donee.remove({
					donee_id: req.params.donee_id
				}, function(err, donee) {
					if (err)
						res.send(err);
		
					res.json({ message: 'Donee Successfully deleted'+donee.donee_id });
				});
			});
		

/*************DONEE ENDS***** */

/*******NGO STARTS*********** */
router.route('/ngo')

	// create a ngo (accessed at POST http://localhost:8080/ngo)
	.post(function(req, res) {
		
		var ngo = new Ngo();		// create a new instance of the Causes model
		ngo.ngo_id = req.body.ngo_id;   
		ngo.ngo_name = req.body.ngo_name;
		ngo.ngo_poc_name = req.body.ngo_poc_name;
		ngo.ngo_mobile_number=req.body.ngo_mobile_number;
		ngo.ngo_address = req.body.ngo_address;
		

		ngo.save(function(err,ngo) {
			if (err)
				res.send(err);

		res.json({ message: 'Ngo created!' + ngo.ngo_id });
		});

		
	})

	// get all the ngo (accessed at GET http://localhost:8080/api/ngo)
	.get(function(req, res) {
		Ngo.find(function(err, ngo) {
			if (err)
				res.send(err);

			res.json(ngo);
		});
	})

		// update the ngo with this id
	.put(function(req, res) {
		var ngo = {};		// create a new instance of the Causes model
		//var id = new mongoose.Types.ObjectId();
		//causes._id=id;

		ngo.ngo_id = req.body.ngo_id;   
		ngo.ngo_name = req.body.ngo_name;
		ngo.ngo_poc_name = req.body.ngo_poc_name;
		ngo.ngo_mobile_number=req.body.ngo_mobile_number;
		ngo.ngo_address = req.body.ngo_address;
		

			Ngo.findOneAndUpdate({ngo_id : req.body.ngo_id},{$set: ngo}, { multi: false, upsert: true },function(err, ngo) {	
			if (err)
					res.send(err);
	
			res.json({ message: 'Cause updated! ' + ngo.ngo_id});
		});
	
			});

 

router.route('/ngo/:ngo_id')

	// get the cause with that id
	.get(function(req, res) {
			Ngo.find({ngo_id : {$eq:req.params.ngo_id}}, function(err, ngo) {
			if (err)
				res.send(err);
			res.json(ngo);
			});
	})
	// delete the ngo with this id
	.delete(function(req, res) {
		Ngo.remove({
			ngo_id: req.params.ngo_id
		}, function(err, ngo) {
			if (err)
				res.send(err);

			res.json({ message: 'Successfully deleted '+ ngo_id });
		});
	});


/************ NGO ENDS**** */

/****** Projects starts***** */
router.route('/projects')

	// create a project  (accessed at POST http://localhost:8080/project)
	.post(function(req, res) {
		
		var projects = new Projects();		// create a new instance of the Causes model
		projects.project_id = req.body.project_id;  
		projects.project_name = req.body.project_name;
		projects.donationcamp_id = req.body.donationcamp_id;
		projects.donationcamp_name= req.body.donationcamp_name;
		projects.donationcamp_status = req.body.donationcamp_status;
		projects.cause_id = req.body.cause_id;
		projects.project_status = req.body.project_status;
		projects.comments = req.body.comments;


		projects.save(function(err,projects) {
			if (err)
				res.send(err);

		res.json({ message: 'project created! '+projects.project_id });
		});

		
	})

	// get all the projects (accessed at GET http://localhost:8080/api/projects)
	.get(function(req, res) {
		Projects.find(function(err, project) {
			if (err)
				res.send(err);

			res.json(project);
		});
	})

		// update the project with this id
	.put(function(req, res) {
		var projects = {};		// create a new instance of the Causes model

		projects.project_id = req.body.project_id; 
		projects.project_name = req.body.project_name;
		projects.donationcamp_id = req.body.donationcamp_id;
		projects.donationcamp_name= req.body.donationcamp_name;
		projects.donationcamp_status = req.body.donationcamp_status;
		projects.cause_id = req.body.cause_id;
		projects.project_status = req.body.project_status;
		projects.comments = req.body.comments;




		Projects.findOneAndUpdate({project_id : req.body.project_id},{$set: projects}, { multi: false, upsert: true },function(err, project) {	
			if (err)
					res.send(err);
		
			res.json({ message: 'Project updated! '+projects.project_id});
		});
	
			});

 

router.route('/projects/:project_id')

	// get the cause with that id
	.get(function(req, res) {
			Projects.find({project_id : {$eq:req.params.project_id}}, function(err, project) {
			if (err)
				res.send(err);
			res.json(project);
			});
	})
	// delete the project  with this id
	.delete(function(req, res) {
		Projects.remove({
			project_id: req.params.project_id
		}, function(err, project) {
			if (err)
				res.send(err);

			res.json({ message: 'Project '+ req.params.project_id + ' Successfully deleted' });
		});
	});



/****** Projects ends******* */

/***** Donations Starts */
router.route('/donations')

	// create a donation (accessed at POST http://localhost:8080/donations)
	.post(function(req, res) {
		
		var donations = new Donations();		// create a new instance of the Causes model
		donations.donation_id = req.body.donation_id;  
		donations.donation_name = req.body.donation_name;
		donations.donation_cause = req.body.donation_cause;
		donations.donation_items = req.body.donation_items;
		donations.donation_amount = req.body.donation_amount;
		donations.project_status = req.body.project_status;
		donations.donor_comments = req.body.donor_comments;


		donations.save(function(err,donations) {
			if (err)
				res.send(err);

		res.json({ message: 'Donation'+donations.donation_id+' created! ' });
		});

		
	})

	// get all the donations (accessed at GET http://localhost:8080/api/donations)
	.get(function(req, res) {
		Donations.find(function(err, donation) {
			if (err)
				res.send(err);

			res.json(donation);
		});
	})

		// update the donation with this id
	.put(function(req, res) {
		var donations = {};		// create a new instance of the Causes model

		donations.donation_id = req.body.donation_id;  
		donations.donation_name = req.body.donation_name;
		donations.donation_cause = req.body.donation_cause;
		donations.donation_items = req.body.donation_items;
		donations.donation_amount = req.body.donation_amount;
		donations.project_status = req.body.project_status;
		donations.donor_comments = req.body.donor_comments;

		Donations.findOneAndUpdate({donation_id : req.body.donation_id},{$set: donations}, { multi: false, upsert: true },function(err, donation) {	
			if (err)
					res.send(err);
		
			res.json({ message: 'Donation'+donations.donation_id+' updated! ' });
		});
	
			});

 

router.route('/donations/:donation_id')

	// get the cause with that id
	.get(function(req, res) {
			Donations.find({donation_id : {$eq:req.params.donation_id}}, function(err, donation) {
			if (err)
				res.send(err);
			res.json(donation);
			});
	})
	// delete the donation with this id
	.delete(function(req, res) {
		Donations.remove({
			donation_id: req.params.donation_id
		}, function(err, donations) {
			if (err)
				res.send(err);

		res.json({ message: 'Donation '+ req.params.donation_id + ' Successfully deleted' });
		});
	});
/*********Donations ends */

/***** Volunteer Starts**** */
router.route('/volunteer')

	// create a volunteer (accessed at POST http://localhost:8080/volunteer)
	.post(function(req, res) {
		
		var volunteer = new Volunteer();		// create a new instance of the Causes model
		volunteer.volunteer_id = req.body.volunteer_id;  
		volunteer.volunteer_name = req.body.volunteer_name;
		volunteer.volunteer_mobile_number = req.body.volunteer_mobile_number;
		volunteer.volunteer_email_id = req.body.volunteer_email_id;
		volunteer.volunteer_address = req.body.volunteer_address;
		volunteer.volunteer_gove_id_proof = req.body.volunteer_gove_id_proof;
		volunteer.volunteer_biometric_details = req.body.volunteer_biometric_details;
		volunteer.volunteer_photo = req.body.volunteer_photo;
		volunteer.volunteer_comments = req.body.volunteer_comments; 

		volunteer.save(function(err) {
			if (err)
				res.send(err);

			res.json({ message: 'Volunteer '+req.body.volunteer_id+' created!' });
		});

		
	})

	// get all the volunteer (accessed at GET http://localhost:8080/api/volunteer)
	.get(function(req, res) {
		Volunteer.find(function(err, volunteer) {
			if (err)
				res.send(err);

			res.json(volunteer);
		});
	})

		// update the volunteer with this id
	.put(function(req, res) {
		var volunteer = {};		// create a new instance of the Causes model
	
		volunteer.volunteer_id = req.body.volunteer_id;  
		volunteer.volunteer_name = req.body.volunteer_name;
		volunteer.volunteer_mobile_number = req.body.volunteer_mobile_number;
		volunteer.volunteer_email_id = req.body.volunteer_email_id;
		
		volunteer.volunteer_address = req.body.volunteer_address;
		volunteer.volunteer_gove_id_proof = req.body.volunteer_gove_id_proof;
		volunteer.volunteer_biometric_details = req.body.volunteer_biometric_details;
		volunteer.volunteer_photo = req.body.volunteer_photo;
		volunteer.volunteer_comments = req.body.volunteer_comments; 


		Volunteer.findOneAndUpdate({volunteer_id : req.body.volunteer_id},{$set: volunteer}, { multi: false, upsert: true },function(err, volunteer) {	
			if (err)
					res.send(err);
			
			res.json({ message: 'Volunteer'+req.body.volunteer_id+' updated!'});
		});
	
			});

	router.route('/volunteer/:volunteer_id')

			// get the cause with that id
			.get(function(req, res) {
					Volunteer.find({volunteer_id : {$eq:req.params.volunteer_id}}, function(err, volunteer) {
					if (err)
						res.send(err);
					res.json(volunteer);
					});
			})
			// delete the volunteer with this id
			.delete(function(req, res) {
				Volunteer.remove({
					volunteer_id: req.params.volunteer_id
				}, function(err, volunteer) {
					if (err)
						res.send(err);
		
					res.json({ message: 'Volunteer '+req.params.volunteer_id+'Successfully deleted' });
				});
			});
		

/****** Volunteer Ends** */

/**** Transactions Starts */
router.route('/transactions')

	// create a transaction (accessed at POST http://localhost:8080/transactions)
	.post(function(req, res) {
		
		var transactions = new Transactions();		// create a new instance of the Causes model
		transactions.transaction_id = req.body.transaction_id;
		transactions.ngo_id = req.body.ngo_id;
		transactions.donor_id = req.body.donor_id;
		transactions.donation_id = req.body.donation_id;
		transactions.volunteer_id = req.body.volunteer_id;
		transactions.donee_id = req.body.donee_id;
		transactions.comments = req.body.comments;


		transactions.save(function(err,transactions) {
			if (err)
				res.send(err);

			res.json({ message: 'Transaction '+req.body.transaction_id+' data inserted! ' });
		});

		
	})

	// get all the transactions (accessed at GET http://localhost:8080/api/transactions)
	.get(function(req, res) {
		Transactions.find(function(err, transaction) {
			if (err)
				res.send(err);

			res.json(transaction);
		});
	});
/*
		// update the  with this id
	.put(function(req, res) {
		var transactions = {};		

		transactions.transaction_id = req.body.transaction_id;  
		transactions.ngo_id = req.body.ngo_id;
		transactions.donor_id = req.body.donor_id;
		transactions.donation_id = req.body.donation_id;
		transactions.volunteer_id = req.body.volunteer_id;
		transactions.donee_id = req.body.donee_id;
		transactions.comments = req.body.comments;

		Transactions.findOneAndUpdate({transaction_id : req.body.transaction_id},{$set: transactions}, { multi: false, upsert: true },function(err, transaction) {	
			if (err)
					res.send(err);
		
			res.json({ message: 'Transaction '+req.body.transaction_id+' updated! ' });
		});
	
			});

 */

router.route('/transactions/:transaction_id')

	.get(function(req, res) {
			Transactions.find({transaction_id : {$eq:req.params.transaction_id}}, function(err, transaction) {
			if (err)
				res.send(err);
			res.json(transaction);
			});
	});
	// delete the transaction with this id
/*	.delete(function(req, res) {
		Transactions.remove({
			transaction_id: req.params.transaction_id
		}, function(err, transaction) {
			if (err)
				res.send(err);

			res.json({ message: 'Transaction '+ req.params.transaction_id + ' Successfully deleted' });
		});
	});
*/	
/***** Transactions Ends */
// REGISTER OUR ROUTES -------------------------------
app.use('/api', router);

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('goodchar api running on port ' + port);
