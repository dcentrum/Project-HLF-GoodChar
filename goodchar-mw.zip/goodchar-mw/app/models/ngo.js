var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var NgoSchema   = new Schema({
	ngo_id: Number,
	ngo_name: String,
	ngo_poc_name: String,
	ngo_mobile_number: Number,
	ngo_address: String
});

module.exports = mongoose.model('Ngo', NgoSchema);