var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;



var DonorSchema   = new Schema({
	donor_id: Number,
	donor_name: String,
	donor_mobile_number: Number,
	donor_donated_items: Number,
	donor_donated_amount: Number,
	donor_email_id: String,
	donor_address: String,
	donor_gove_id_proof: String,
	donor_biometric_details: String,
	donor_photo: String,
	donor_comments: String
});

module.exports = mongoose.model('Donor', DonorSchema);