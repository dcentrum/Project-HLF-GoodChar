var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;


var ProjectsSchema   = new Schema({
	project_id: Number,
	project_name: String,
	donationcamp_id: Number,
	donationcamp_name: String,
	donationcamp_status: String,
	cause_id: Number,
	project_status: String,
	comments: String
});

module.exports = mongoose.model('Projects', ProjectsSchema);