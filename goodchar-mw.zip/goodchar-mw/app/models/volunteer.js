var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var VolunteerSchema   = new Schema({
	volunteer_id: Number,
	volunteer_name: String,
	volunteer_mobile_number: Number,
	volunteer_email_id: String,
	volunteer_address: String,
	volunteer_gove_id_proof: String,
	volunteer_biometric_details: String,
	volunteer_photo: String,
	volunteer_comments: String
});

module.exports = mongoose.model('Volunteer', VolunteerSchema);