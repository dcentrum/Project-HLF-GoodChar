var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;



var DonationsSchema   = new Schema({
	donation_id: Number,
	donation_name: String,
	donation_cause: Number,
	donation_items: Number,
	donation_amount: Number,
	donor_comments: String
});

module.exports = mongoose.model('Donations', DonationsSchema);
