var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;


var CausesSchema   = new Schema({
	cause_id: Number,
	cause_name: String,
	cause_type: String,
	comments: String
});

module.exports = mongoose.model('Causes', CausesSchema);

