var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;
var DoneeSchema   = new Schema({
	donee_id: Number,
	donee_name: String,
	donee_mobile_number: Number,
	donee_received_items: Number,
	donee_received_amount: Number,
	donee_email_id: String,
	donee_address: String,
	donee_gove_id_proof: String,
	donee_biometric_details: String,
	donee_photo: String,
	donee_comments: String
});

module.exports = mongoose.model('Donee', DoneeSchema);
