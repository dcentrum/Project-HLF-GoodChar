var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var TransactionsSchema   = new Schema({
	transaction_id: Number,
	ngo_id: Number,
	donor_id: Number,
	donation_id: Number,
	volunteer_id: Number,
	donee_id: Number,
	comments: String
});

module.exports = mongoose.model('Transactions', TransactionsSchema);